# Lab 5 — Reflection

> The supplied handout explains the purpose of the tools but does not show the four reflection questions themselves. These responses cover four standard reflection prompts relevant to this lab; replace the prompts if your instructor supplied a separate question sheet.

## 1. What is static code analysis, and why is it useful?

Static code analysis checks source code without running the application. It helps identify likely bugs, insecure patterns, maintainability problems, and style violations early, before they become runtime failures or production incidents.

## 2. What are the differences between Pylint, Bandit, and Flake8?

Pylint checks broader code quality and programming practices, including naming, documentation, unused variables, and design concerns. Bandit focuses on common security risks in Python source code. Flake8 checks style and formatting rules and reports many PEP 8 violations. Their scopes overlap in places, so using all three gives complementary feedback.

## 3. Which issues were most important, and how were they fixed?

The most important issues were the shell command built with user-controlled input and the insecure temporary-file helper. The shell command was replaced with hostname resolution through the socket API, avoiding shell interpretation. The temporary path now comes from `NamedTemporaryFile`, which creates a unique file safely. The mutable list default was replaced with `None`, and the broad exception handler now catches only `KeyError`.

## 4. How does static analysis improve code quality, and what are its limitations?

It makes code easier to review, maintain, and secure by consistently surfacing patterns that developers might overlook. It does not prove that a program is correct, and it cannot reliably detect every runtime or business-logic problem. Findings must be reviewed, the program should still be tested, and the tools should be rerun after fixes. In this lab, the demonstration output and compilation were checked, but the three analysis tools still need to be run in the student's local environment because they could not be installed in the preparation environment.
