
"""Demonstrate booking and tracking parcels for a courier service."""

import secrets
import socket
import tempfile
from datetime import date
from pathlib import Path
from typing import Any

STATUS_FLOW = (
    "Booked",
    "Picked Up",
    "In Transit",
    "Out for Delivery",
    "Delivered",
)
parcels: dict[str, dict[str, Any]] = {}


def book_parcel(
    sender: str,
    receiver: str,
    weight_kg: float,
    history: list[str] | None = None,
) -> str:
    """Book a parcel and optionally append its tracking ID to history."""
    if weight_kg <= 0:
        raise ValueError("Parcel weight must be greater than zero.")

    if history is None:
        history = []

    tracking_id = f"TRK{10001 + len(parcels)}"
    parcels[tracking_id] = {
        "sender": sender,
        "receiver": receiver,
        "weight": weight_kg,
        "status": 0,
        "booked": str(date.today()),
    }
    history.append(tracking_id)
    return tracking_id


def advance_status(tracking_id: str) -> str:
    """Advance a parcel by one stage, stopping at Delivered."""
    parcel = parcels[tracking_id]

    if parcel["status"] < len(STATUS_FLOW) - 1:
        parcel["status"] += 1

    return STATUS_FLOW[parcel["status"]]


def shipping_cost(weight_kg: float) -> float:
    """Calculate shipping cost: 50 for the first kg and 30 per extra kg."""
    if weight_kg <= 0:
        raise ValueError("Parcel weight must be greater than zero.")

    cost = 50.0
    if weight_kg > 1:
        cost += (weight_kg - 1) * 30

    return round(cost, 2)


def track_parcel(tracking_id: str) -> str:
    """Return route and status, or a clear message for an unknown ID."""
    try:
        parcel = parcels[tracking_id]
    except KeyError:
        return f"Unknown tracking id {tracking_id}"

    route = f"{parcel['sender']} -> {parcel['receiver']}"
    return f"{route}: {STATUS_FLOW[parcel['status']]}"


def is_with_courier(tracking_id: str) -> bool:
    """Return whether a parcel is picked up or in transit."""
    status = STATUS_FLOW[parcels[tracking_id]["status"]]
    return status in ("Picked Up", "In Transit")


def label_path() -> str:
    """Create a securely named temporary label path."""
    with tempfile.NamedTemporaryFile(
        suffix=".txt",
        delete=False,
    ) as temp_file:
        return str(Path(temp_file.name))


def resolve_hub(hub_address: str) -> list[tuple[Any, ...]]:
    """Resolve a hub hostname without invoking a shell command."""
    return socket.getaddrinfo(hub_address, None)


def main() -> None:
    """Run the parcel-tracking demonstration."""
    first = book_parcel("Bengaluru Books", "Ravi Kumar", 2.5)
    second = book_parcel("Gadget Hub", "Sneha Rao", 0.8)
    third = book_parcel("Spice Store", "Imran Khan", 4)

    advance_status(first)
    advance_status(first)
    advance_status(second)

    for _ in range(6):
        advance_status(third)

    for tracking_id in (first, second, third):
        print(track_parcel(tracking_id))
        print("  with courier:", is_with_courier(tracking_id))
        print("  cost:", shipping_cost(parcels[tracking_id]["weight"]))

    print(track_parcel("TRK00000"))
    delivery_otp = secrets.randbelow(9000) + 1000
    print("Delivery OTP for", third, "is", delivery_otp)
    print("Parcels booked today:", len(parcels))


if __name__ == "__main__":
    main()
