# Static Code Analysis Issue Log — Parcel Tracker

The line numbers below refer to the original `parcel_tracker.py` supplied in the repository. Findings were identified by source inspection against the types of issues targeted by Pylint, Bandit, and Flake8. The static-analysis packages could not be installed in the preparation environment because package-network access was unavailable; therefore, these are **not claimed to be tool-generated report findings**. Run the commands in `README.md` locally and update line numbers/messages to match your actual reports.

| Issue | Type | Original line(s) | Description | Fix approach |
|---|---|---:|---|---|
| Shell command with `shell=True` | Security / Bandit | 55 | Concatenating `hubAddress` into a shell command risks command injection. | Removed shell execution and use `socket.getaddrinfo()` for hostname resolution instead. Renamed helper to `resolve_hub` to accurately describe its behavior. |
| Insecure temporary filename | Security / Bandit | 50 | `tempfile.mktemp()` can introduce a race condition because the file is not created atomically. | Use `NamedTemporaryFile(delete=False)` to allocate a unique file securely. |
| Mutable default argument | Bug / Pylint | 11 | `history=[]` is shared across calls, so tracking IDs can leak between calls. | Default to `None`, then initialize a fresh list inside the function. |
| Overly broad exception | Reliability / Pylint | 37 | `except Exception` can hide unrelated programming errors. | Catch only `KeyError`, the exception raised when the tracking ID is missing. |
| Non-PEP 8 identifiers | Style / Pylint, Flake8 | 11, 20, 27, 34, 43 | Function names and parameters use mixed/camel case. | Rename functions and variables to `snake_case`. |
| Whitespace and long lines | Style / Flake8 | 28, 71, 74 | Missing spaces around assignment, inline comment spacing, and cramped formatting. | Apply consistent spacing and split/format statements. |
| Unprotected module entry point | Maintainability / Pylint | 75 | Calling `main()` at import time runs the demo when the module is imported for testing. | Guard execution with `if __name__ == "__main__":`. |
| Missing input validation | Robustness | 11, 27 | Zero or negative parcel weights produce nonsensical shipping costs. | Reject non-positive weights with `ValueError`. |

## Verification commands

```bash
python -m pip install pylint bandit flake8
python -m pylint parcel_tracker.py > pylint_after.txt 2>&1
python -m bandit -r parcel_tracker.py > bandit_after.txt 2>&1
python -m flake8 parcel_tracker.py > flake8_after.txt 2>&1
```

Do not submit a claimed Pylint score until it appears in the actual `pylint_after.txt` output. The handout asks for a score above 9.5 and no remaining Bandit/Flake8 findings.
